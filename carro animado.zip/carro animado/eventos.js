var carrito = document.querySelector('.carro')
var fondo = document.querySelector('.fondo')
var llantade = document.querySelector('.llantade')
var llantata = document.querySelector('.llantatra')
var polvo = document.querySelector('.polvo')

carrito.addEventListener('click', animations)

function animations(){
    fondo.classList.add('fondo_animado')
    llantade.classList.add('llantadelantera')
    llantata.classList.add('llantatrasera')
    polvo.classList.add('oculto')
}

